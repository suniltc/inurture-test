<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      	<!-- Small boxes (Stat box) -->
      	<div class="row">
        	<div class="col-lg-6 col-xs-6">
          	<!-- small box -->
          		<div class="small-box bg-aqua">
            		<div class="inner">
              		<h3><?php echo e($number_of_users); ?></h3>
              		<p>Number of users</p>
            	</div>
            	<div class="icon">
              		<i class="ion ion-bag"></i>
            	</div>
          		</div>
        	</div>
        	
        	<!-- ./col -->
        	<div class="col-lg-6 col-xs-6">
          	<!-- small box -->
          		<div class="small-box bg-green">
            		<div class="inner">
              			<h3><?php echo e($number_of_courses); ?></h3>
              			<p>Number of courses</p>
            		</div>
            		<div class="icon">
			            <i class="ion ion-stats-bars"></i>
			        </div>
          		</div>
        	</div>
    </div>
      <!-- /.row -->
      <!-- Main row -->

      <div class="box">
        <div class="box-header">
            <h3 class="box-title">CourseWise Number of students</h3>
        </div><!-- /.box-header -->
        <div class="box-body table-responsive">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Course Name</th>
                        <th>Number of Students</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $number_of_coursewise_students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($student->name); ?></td>
                            <td><?php echo e($student->students); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Course Name</th>
                        <th>Number of Students</th>
                    </tr>
                </tfoot>
            </table>
        </div><!-- /.box-body -->
    </div><!-- /.box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>